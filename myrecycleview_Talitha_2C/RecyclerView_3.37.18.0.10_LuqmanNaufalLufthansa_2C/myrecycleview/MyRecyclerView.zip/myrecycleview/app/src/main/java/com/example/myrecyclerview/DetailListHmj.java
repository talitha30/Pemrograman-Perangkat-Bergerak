package com.example.myrecyclerview;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailListHmj extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstaceState) {
        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_detail_list_hmj);
    }
}
